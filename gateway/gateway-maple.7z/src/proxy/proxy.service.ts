import { Inject, Injectable } from '@nestjs/common';
import { ClientProxy } from '@nestjs/microservices';
import { Observable } from 'rxjs';

@Injectable()
export class ProxyService {
  constructor(
    @Inject('AUTH_SERVICE') private readonly authClient: ClientProxy,
    @Inject('EVENT_SERVICE') private readonly eventClient: ClientProxy,
  ) {}

  // Auth 서비스로 요청 전달
  sendToAuthService(pattern: string, data: any): Observable<any> {
    // 요청에 사용자 정보가 있으면 그대로 전달
    return this.authClient.send(pattern, data);
  }

  // Event 서비스로 요청 전달
  sendToEventService(pattern: string, data: any): Observable<any> {
    // 요청에 사용자 정보가 있으면 그대로 전달
    return this.eventClient.send(pattern, data);
  }
}
